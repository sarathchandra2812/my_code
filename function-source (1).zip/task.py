# Sample Code:
# print(event.get('task_string_key'))
# event.set('task_int_array_key', [456, 789]);
# event.log('some logging')
from google.cloud import storage
import json

def run(event):
  """Actual cloud function custom logic.
  Args:
    event : event object in main.py that contains all parameters.
  """

  print("="*1000)
  print(dir(event))
  print("="*1000)


  data = event.get("`Task_1_connectorOutputPayload`")
  print("+"*1000)
  print(data)
  print("+"*1000)

  bucket_name = 'sarath_dataflow'
  bucket = storage.Client().get_bucket(bucket_name)
  blob = bucket.blob('data_test2.json')
  blob.upload_from_string(data=json.dumps(data),content_type='application/json')

  return data
